GRANDPA JOE - 2026 KENTUCKY DERBY DAY SHARE BUNDLE
==================================================

Open START_HERE.html (double-click) for the dashboard.

Contents:
  START_HERE.html                 main landing page
  bundle/race_3d/                 14 animated race playbacks + index
  docs/                           printable betting sheets (PDF)
  README.txt                      this file

Need internet to play the animations (Plotly library loads from CDN).
Everything else works offline.

Built Fri May 01 2026 02:51 PM by Grandpa Joe (DJR / CAMDAN).
